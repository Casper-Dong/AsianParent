import { useState, useEffect } from "react";

const brokenEnglish = [
  "no play game, go study",
  "why you sleep so late",
  "you eat yet?",
  "i tell you already",
  "this how you get A?",
  "last time I do better than you",
  "no phone now, study first",
  "i come back you better finish homework",
];

const chinesePhrases = [
  "加油",
  "你吃了吗",
  "快点",
  "不要浪费时间",
  "我很失望",
  "你听到了吗？",
];

const oneWorders = [
  "okay",
  "why",
  "huh",
  "good",
  "no",
  "yes",
  "aiyo",
  "tsk",
];

const emojiReactions = ["👍", "😒", "🙄", "😂", "😠", "👀"];

const getRandomMessage = () => {
  const category = ["broken", "chinese", "oneword"][Math.floor(Math.random() * 3)];
  if (category === "broken") return brokenEnglish[Math.floor(Math.random() * brokenEnglish.length)];
  if (category === "chinese") return chinesePhrases[Math.floor(Math.random() * chinesePhrases.length)];
  return oneWorders[Math.floor(Math.random() * oneWorders.length)];
};

const getRandomEmoji = () => {
  return emojiReactions[Math.floor(Math.random() * emojiReactions.length)];
};

export default function App() {
  const [messages, setMessages] = useState([]);

  const sendMessage = () => {
    const newMessage = getRandomMessage();
    const emoji = getRandomEmoji();
    setMessages((prev) => [...prev, { sender: "parent", text: newMessage, emoji }]);
  };

  useEffect(() => {
    const interval = setInterval(() => {
      sendMessage();
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="p-4 max-w-md mx-auto">
      <h1 className="text-2xl font-bold mb-4 text-center">Asian Parent Text Simulator</h1>
      <div className="h-96 overflow-y-auto p-2 border rounded-xl shadow-inner bg-white space-y-2 flex flex-col">
        {messages.map((msg, index) => (
          <div key={index} className="flex flex-col items-start">
            <div className="rounded-xl p-2 max-w-xs bg-gray-200 text-left">{msg.text}</div>
            <div className="text-sm mt-1 ml-2">{msg.emoji}</div>
          </div>
        ))}
      </div>
      <div className="flex justify-center mt-4">
        <button onClick={sendMessage} className="px-4 py-2 bg-blue-500 text-white rounded-xl shadow hover:bg-blue-600 transition">
          Send Another Text
        </button>
      </div>
    </div>
  );
}
